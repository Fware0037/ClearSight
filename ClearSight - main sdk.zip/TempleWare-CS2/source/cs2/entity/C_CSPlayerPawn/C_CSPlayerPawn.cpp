﻿#include "C_CSPlayerPawn.h"

#include "../../../templeware/offsets/offsets.h"
#include "../../../templeware/interfaces/interfaces.h"
#include <source\templeware\config\config.h>
#include <source\templeware\hooks\hooks.h>

C_CSPlayerPawn::C_CSPlayerPawn(uintptr_t address) : address(address) {}

Vector_t C_CSPlayerPawn::getPosition() const {
	return *(Vector_t*)(address + SchemaFinder::Get(hash_32_fnv1a_const("C_BasePlayerPawn->m_vOldOrigin")));
}

int C_CSPlayerPawn::getFlags() const {
	return *(int*)((uintptr_t)this + 0x9C); 
}

Vector_t C_CSPlayerPawn::getEyePosition() const {
	return Vector_t();
}

C_CSWeaponBase* C_CSPlayerPawn::GetActiveWeapon() const {
	if (!this)
		return nullptr;

	CCSPlayer_WeaponServices* weapon_services = this->GetWeaponServices();
	if (weapon_services == nullptr)
		return nullptr;

	C_CSWeaponBase* active_weapon = I::GameEntity->Instance->Get<C_CSWeaponBase>(weapon_services->m_hActiveWeapon());
	if (!active_weapon)
		return nullptr;

	return active_weapon;
}

CCSPlayer_WeaponServices* C_CSPlayerPawn::GetWeaponServices() const {
	if (!address) return nullptr;
	return reinterpret_cast<CCSPlayer_WeaponServices*>((uintptr_t)this + SchemaFinder::Get(hash_32_fnv1a_const("C_CSPlayerPawn->m_pWeaponServices")));
}

uintptr_t C_CSPlayerPawn::getAddress() const {
	return address;
}

int C_CSPlayerPawn::getHealth() const {
	return *reinterpret_cast<int*>((uintptr_t)this + SchemaFinder::Get(hash_32_fnv1a_const("C_BaseEntity->m_iHealth")));
}

uint8_t C_CSPlayerPawn::getTeam() const {
	return *reinterpret_cast<uint8_t*>((uintptr_t)this + SchemaFinder::Get(hash_32_fnv1a_const("C_BaseEntity->m_iTeamNum")));
}

Vector_t C_CSPlayerPawn::getViewOffset() const {
	return *reinterpret_cast<Vector_t*>((uintptr_t)this + SchemaFinder::Get(hash_32_fnv1a_const("C_BaseModelEntity->m_vecViewOffset")));
}

Vector_t C_CSPlayerPawn::GetOrigin() const {
	return *reinterpret_cast<Vector_t*>((uintptr_t)this + SchemaFinder::Get(hash_32_fnv1a_const("C_BaseEntity->m_vecOrigin")));
}

Vector_t C_CSPlayerPawn::GetViewOffset() const {
	return *reinterpret_cast<Vector_t*>((uintptr_t)this + SchemaFinder::Get(hash_32_fnv1a_const("C_BaseModelEntity->m_vecViewOffset")));
}
 
bool C_CSPlayerPawn::IsScoped() const {
	return *reinterpret_cast<bool*>((uintptr_t)this + SchemaFinder::Get(hash_32_fnv1a_const("C_CSPlayerPawn->m_bIsScoped")));
}



bool C_CSPlayerPawn::IsSpotted()
{
	return *reinterpret_cast<bool*>((uintptr_t)this + SchemaFinder::Get(hash_32_fnv1a_const("EntitySpottedState_t->m_bSpotted")));
}

uint32_t C_CSPlayerPawn::SpottedByMask()
{
	return *reinterpret_cast<uint32_t*>((uintptr_t)this + SchemaFinder::Get(hash_32_fnv1a_const("EntitySpottedState_t->m_bSpottedByMask")));
}

bool C_CSPlayerPawn::ShouldDraw()
{
	C_CSPlayerPawn* lp = H::oGetLocalPlayer(0);

	if (this->getHealth() <= 0)  // Игрок мёртв, не отображать
		return false;

	if (Config::aimbot_teamcheck && this->getTeam() == lp->getTeam()) // Игрок на той же команде
		return false;

	return true;
}

void C_CSPlayerPawn::SetViewmodelOffsetX(float value) {
	*reinterpret_cast<float*>((uintptr_t)this + SchemaFinder::Get(hash_32_fnv1a_const("C_CSPlayerPawn->m_flViewmodelOffsetX"))) = value;
}

void C_CSPlayerPawn::SetViewmodelOffsetY(float value) {
	*reinterpret_cast<float*>((uintptr_t)this + SchemaFinder::Get(hash_32_fnv1a_const("C_CSPlayerPawn->m_flViewmodelOffsetY"))) = value;
}

void C_CSPlayerPawn::SetViewmodelOffsetZ(float value) {
	*reinterpret_cast<float*>((uintptr_t)this + SchemaFinder::Get(hash_32_fnv1a_const("C_CSPlayerPawn->m_flViewmodelOffsetZ"))) = value;
}

void C_CSPlayerPawn::SetViewmodelFOV(float value) {
	*reinterpret_cast<float*>((uintptr_t)this + SchemaFinder::Get(hash_32_fnv1a_const("C_CSPlayerPawn->m_flViewmodelFOV"))) = value;
}

void C_CSPlayerPawn::SetAspectRatio(float value) {
	*reinterpret_cast<float*>((uintptr_t)this + SchemaFinder::Get(hash_32_fnv1a_const("C_PointCamera->m_flAspectRatio"))) = value;
}

