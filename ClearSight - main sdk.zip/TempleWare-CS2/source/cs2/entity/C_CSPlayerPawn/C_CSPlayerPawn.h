#pragma once
#include "../../../templeware/utils/memory/memorycommon.h"
#include "../../../templeware/utils/math/vector/vector.h"
#include "../../../templeware/utils/schema/schema.h"
#include "../C_CSWeaponBase/C_CSWeaponBase.h"
#include "../C_BaseEntity/C_BaseEntity.h"

#include <cstdint>

class C_CSPlayerPawn : public C_BaseEntity {
public:
	SCHEMA_ADD_OFFSET(Vector_t, m_vOldOrigin, 0x1324);
	SCHEMA_ADD_OFFSET(Vector_t, m_vecViewOffset, 0xCB0);
	SCHEMA_ADD_OFFSET(CCSPlayer_WeaponServices*, m_pWeaponServices, 0x11A8);
	SCHEMA_ADD_OFFSET(CBaseHandle, m_hPawn, 0x62C); // old 0x11A0
	SCHEMA_ADD_OFFSET(bool, m_bIsScoped, 0x23E8);
	SCHEMA_ADD_OFFSET(bool, m_bSpotted, 0x8); // bool
	SCHEMA_ADD_OFFSET(uint32_t, m_bSpottedByMask, 0xC); // uint32[2]
	SCHEMA_ADD_OFFSET(float, m_flViewmodelOffsetX, 0x22C8);
	SCHEMA_ADD_OFFSET(float, m_flViewmodelOffsetY, 0x22CC);
	SCHEMA_ADD_OFFSET(float, m_flViewmodelOffsetZ, 0x22D0);
	SCHEMA_ADD_OFFSET(float, m_flViewmodelFOV, 0x22D4);
	SCHEMA_ADD_OFFSET(float, m_flAspectRatio, 0x588);
	C_CSPlayerPawn(uintptr_t address);

	int getShotsFired() {
		return *(int*)((uintptr_t)this + SchemaFinder::Get(hash_32_fnv1a_const("C_CSPlayerPawn->m_iShotsFired")));
	}

	QAngle_t* viewangles = (QAngle_t*)(modules.getModule("client") + 0x1A93300);

	C_CSWeaponBase* GetActiveWeapon()const;
	CCSPlayer_WeaponServices* GetWeaponServices()const;
	Vector_t getPosition() const;
	int getFlags() const;
	Vector_t getEyePosition() const;

	uintptr_t getAddress() const;
	int getHealth() const;
	uint8_t getTeam() const;
	Vector_t getViewOffset() const;
	Vector_t GetOrigin() const;
	Vector_t GetViewOffset() const;
	bool IsScoped() const;
	bool IsSpotted();
	uint32_t SpottedByMask();
	bool ShouldDraw();
	void SetViewmodelOffsetX(float value);
	void SetViewmodelOffsetY(float value);
	void SetViewmodelOffsetZ(float value);
	void SetViewmodelFOV(float value);
	void SetAspectRatio(float value);
private:
	uintptr_t address;
};
