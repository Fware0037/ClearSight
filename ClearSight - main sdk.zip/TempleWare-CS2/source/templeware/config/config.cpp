﻿#include "config.h"

// CBA to make proper atm, it's 03:42 right now.
// For now just stores config values don't mind it too much
//
// (FYI THIS IS A HORRID SOLUTION BUT FUNCTIONS) 

namespace Config {
	bool esp = false;
	bool glow = false;
	bool showHealth = false;
	bool teamCheck = false;
	bool espFill = false;
	bool showNameTags = false;
	
	bool Night = false;
	
	bool enemyChamsInvisible = false;
	bool enemyChams = false;
	bool teamChams = false;
	bool teamChamsInvisible = false;
	int chamsMaterial = 0;


	bool armChams = false;
	bool viewmodelChams = false;
	ImVec4 colViewmodelChams = ImVec4(1, 0, 0, 1);
	ImVec4 colArmChams = ImVec4(1, 0, 0, 1);

	ImVec4 colVisualChams = ImVec4(1, 0, 0, 1);
	ImVec4 colVisualChamsIgnoreZ = ImVec4(1, 0, 0, 1);
	ImVec4 teamcolVisualChamsIgnoreZ = ImVec4(1, 0, 0, 1);
	ImVec4 teamcolVisualChams = ImVec4(1, 0, 0, 1);

	float espThickness = 1.0f;
	float espFillOpacity = 0.5f;
	ImVec4 espColor = ImVec4(1, 0, 0, 1);

	bool fovEnabled = false;
	float fov = 90.0f;

	bool antiflash = false;

	ImVec4 NightColor = ImVec4(0.1, 0.1, 0.1, 1);

	bool aimbot = 0;
	float aimbot_fov = 0;
	bool rcs = 0;
	bool fov_circle = 0;
	bool aimbot_wallcheck = 0;
	bool aimbot_teamcheck = 0;
	float aimbot_smooth = 3.f;
	bool aimbot_silent = 0;
	bool aimbot_autoshoot = 0;
	float rcs_strength = 0.5f;
	int aimbot_hitbox = 0;
	ImVec4 fovCircleColor = ImVec4(1.0f, 1.0f, 1.0f, 1.0f);
	bool chatspam = false;
	bool bunnyhop = false;
	bool airstrafe = false;
	bool nosmoke = false;
	bool watermark = true;
	bool autoaccept = false;
	bool enableaspectratio = false;
	float aspectratio = 1.77;
	ImVec4 menucolor = ImVec4(36, 202, 243, 1);
	bool viewmodel_enable = false;
	float viewmodel_x = 0.0f;
	float viewmodel_y = 0.0f;
	float viewmodel_z = 0.0f;
	float viewmodel_fov = 68.0f;
	float viewmodel_xrot = 0.0f;
	float viewmodel_yrot = 0.0f;
	float viewmodel_zrot = 0.0f;
}