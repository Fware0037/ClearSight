#pragma once
#include "../../../external/imgui/imgui.h"

// CBA to make proper atm, it's 03:42 right now.
// For now just stores config values don't mind it too much
//
// (FYI THIS IS A HORRID SOLUTION BUT FUNCTIONS) 

namespace Config {
	extern bool esp;
	extern bool showHealth;
	extern bool teamCheck;
	extern bool espFill;
	extern float espThickness;
	extern float espFillOpacity;
	extern ImVec4 espColor;
	extern bool showNameTags;
	
	extern bool Night;
	extern ImVec4 NightColor;
	
	extern bool enemyChamsInvisible;
	extern bool enemyChams;
	extern bool teamChams;
	extern bool teamChamsInvisible;
	extern int chamsMaterial;

	extern ImVec4 colVisualChams;
	extern ImVec4 colVisualChamsIgnoreZ;
	extern ImVec4 teamcolVisualChamsIgnoreZ;
	extern ImVec4 teamcolVisualChams;

	extern bool armChams;
	extern bool viewmodelChams;
	extern ImVec4 colViewmodelChams;
	extern ImVec4 colArmChams;

	extern bool fovEnabled;
	extern float fov;

	extern bool antiflash;

	extern bool Night;

	extern bool aimbot;
	extern float aimbot_fov;
	extern float aimbot_smooth;
	extern bool aimbot_teamcheck;
	extern bool rcs;
	extern bool aimbot_wallcheck;
	extern bool aimbot_silent;
	extern bool aimbot_autoshoot;
	extern bool aimbot_autoscope;
	extern bool aimbot_flashsmokecheck;
	extern bool fov_circle;
	extern float rcs_strength;
	extern int aimbot_hitbox;
	extern ImVec4 fovCircleColor;
	extern bool chatspam;
	extern bool bunnyhop;
	extern bool airstrafe;
	extern bool nosmoke;
	extern bool watermark;
	extern bool autoaccept;
	extern bool enableaspectratio;
	extern float aspectratio;
	extern ImVec4 menucolor;
	extern bool viewmodel_enable;
	extern float viewmodel_x;
	extern float viewmodel_y;
	extern float viewmodel_z;
	extern float viewmodel_fov;
	extern float viewmodel_xrot;
	extern float viewmodel_yrot;
	extern float viewmodel_zrot;
}
