﻿#pragma once

#include <string>
#include <vector>
#include <filesystem>
#include <fstream>
#include <cstdlib>
#include <iostream> // Для отладки
#include "config.h"
#include "../../../external/json/json.hpp"

namespace internal_config
{
    class ConfigManager
    {
    private:

    public:

        static std::filesystem::path GetConfigFolder()
        {
            char* userProfile = nullptr;
            size_t len = 0;
            errno_t err = _dupenv_s(&userProfile, &len, "USERPROFILE");

            std::filesystem::path folder;
            if (err != 0 || userProfile == nullptr || len == 0)
            {
                folder = ".ClearSight";
            }
            else
            {
                folder = userProfile;
                free(userProfile);
                folder /= ".ClearSight";
            }
            folder /= "internal";

            std::error_code ec;
            if (!std::filesystem::create_directories(folder, ec) && ec)
            {
                std::cerr << "Failed to create config folder: " << ec.message() << std::endl;
            }

            return folder;
        }

        static std::filesystem::path GetConfigPath(const std::string& configName)
        {
            auto folder = GetConfigFolder();
            return folder / (configName + ".priora");
        }

        static std::vector<std::string> ListConfigs()
        {
            std::vector<std::string> list;
            auto folder = GetConfigFolder();
            if (!std::filesystem::exists(folder))
                return list;

            for (const auto& entry : std::filesystem::directory_iterator(folder))
            {
                if (entry.is_regular_file())
                {
                    auto path = entry.path();
                    if (path.extension() == ".priora")
                    {
                        list.push_back(path.stem().string());
                    }
                }
            }
            return list;
        }

        static void Save(const std::string& configName)
        {
            try
            {
                nlohmann::json j;

                // Сериализация данных
                j["esp"] = Config::esp;
                j["showHealth"] = Config::showHealth;
                j["teamCheck"] = Config::teamCheck;
                j["espFill"] = Config::espFill;
                j["espThickness"] = Config::espThickness;
                j["espFillOpacity"] = Config::espFillOpacity;
				j["showNameTags"] = Config::showNameTags;


                j["fovEnabled"] = Config::fovEnabled;
                j["fov"] = Config::fov;

                j["espColor"] = {
                    Config::espColor.x,
                    Config::espColor.y,
                    Config::espColor.z,
                    Config::espColor.w
                };

                j["Night"] = Config::Night;
                j["NightColor"] = {
                    Config::NightColor.x,
                    Config::NightColor.y,
                    Config::NightColor.z,
                    Config::NightColor.w
                };

                j["armChams"] = Config::armChams;
                j["viewmodelChams"] = Config::viewmodelChams;

                j["armChams_color"] = {
                    Config::colArmChams.x,
                    Config::colArmChams.y,
                    Config::colArmChams.z,
                    Config::colArmChams.w
                };

                j["viewmodelChams_color"] = {
                    Config::colViewmodelChams.x,
                    Config::colViewmodelChams.y,
                    Config::colViewmodelChams.z,
                    Config::colViewmodelChams.w
                };

                j["aimbot"] = Config::aimbot;
                j["aimbot_fov"] = Config::aimbot_fov;
				j["aimbot_teamcheck"] = Config::aimbot_teamcheck;
				j["aimbot_wallcheck"] = Config::aimbot_wallcheck;
				j["aimbot_silent"] = Config::aimbot_silent;
				j["aimbot_smooth"] = Config::aimbot_smooth;
				j["aimbot_autoshoot"] = Config::aimbot_autoshoot;
				j["aimbot_hitbox"] = Config::aimbot_hitbox;

                j["antiflash"] = Config::antiflash;
                j["rcs"] = Config::rcs;
				j["rcs_strength"] = Config::rcs_strength;
                j["fov_circle"] = Config::fov_circle;
                j["enemyChamsInvisible"] = Config::enemyChamsInvisible;
                j["enemyChams"] = Config::enemyChams;
                j["teamChams"] = Config::teamChams;
                j["teamChamsInvisible"] = Config::teamChamsInvisible;
                j["chamsMaterial"] = Config::chamsMaterial;

                j["fovCircleColor"] = {
                    Config::fovCircleColor.x,
                    Config::fovCircleColor.y,
                    Config::fovCircleColor.z,
                    Config::fovCircleColor.w
                };

                j["chatspam"] = Config::chatspam;
                j["bunnyhop"] = Config::bunnyhop;
                j["airstrafe"] = Config::airstrafe;
                j["nosmoke"] = Config::nosmoke;
                j["watermark"] = Config::watermark;
                j["autoaccept"] = Config::autoaccept;
                j["enableaspectratio"] = Config::enableaspectratio;
                j["aspectratio"] = Config::aspectratio;

                auto filePath = GetConfigPath(configName);
                std::ofstream ofs(filePath);
                if (!ofs.is_open())
                {
                    std::cerr << "Failed to open config file for saving: " << filePath << std::endl;
                    return;
                }

                ofs << j.dump(4);
                ofs.close();
            }
            catch (const std::exception& e)
            {
                std::cerr << "Error saving config: " << e.what() << std::endl;
            }
        }

        static void Load(const std::string& configName)
        {
            try
            {
                auto filePath = GetConfigPath(configName);
                if (!std::filesystem::exists(filePath))
                {
                    std::cerr << "Config file does not exist: " << filePath << std::endl;
                    return;
                }

                std::ifstream ifs(filePath);
                if (!ifs.is_open())
                {
                    std::cerr << "Failed to open config file for loading: " << filePath << std::endl;
                    return;
                }

                nlohmann::json j;
                ifs >> j;

                // Десериализация данных
                Config::esp = j.value("esp", false);
                Config::showHealth = j.value("showHealth", false);
                Config::teamCheck = j.value("teamCheck", false);
                Config::espFill = j.value("espFill", false);
                Config::espThickness = j.value("espThickness", 1.0f);
                Config::espFillOpacity = j.value("espFillOpacity", 0.5f);

                Config::fovEnabled = j.value("fovEnabled", false);
                Config::fov = j.value("fov", 90.0f);

                if (j.contains("espColor") && j["espColor"].is_array() && j["espColor"].size() == 4)
                {
                    auto arr = j["espColor"];
                    Config::espColor.x = arr[0].get<float>();
                    Config::espColor.y = arr[1].get<float>();
                    Config::espColor.z = arr[2].get<float>();
                    Config::espColor.w = arr[3].get<float>();
                }

                Config::Night = j.value("Night", false);
                if (j.contains("NightColor") && j["NightColor"].is_array() && j["NightColor"].size() == 4)
                {
                    auto arr = j["NightColor"];
                    Config::NightColor.x = arr[0].get<float>();
                    Config::NightColor.y = arr[1].get<float>();
                    Config::NightColor.z = arr[2].get<float>();
                    Config::NightColor.w = arr[3].get<float>();
                }

                if (j.contains("colArmChams") && j["colArmChams"].is_array() && j["colArmChams"].size() == 4)
                {
                    auto arr = j["colArmChams"];
                    Config::colArmChams.x = arr[0].get<float>();
                    Config::colArmChams.y = arr[1].get<float>();
                    Config::colArmChams.z = arr[2].get<float>();
                    Config::colArmChams.w = arr[3].get<float>();
                }

                if (j.contains("colViewmodelChams") && j["colViewmodelChams"].is_array() && j["colViewmodelChams"].size() == 4)
                {
                    auto arr = j["colViewmodelChams"];
                    Config::colViewmodelChams.x = arr[0].get<float>();
                    Config::colViewmodelChams.y = arr[1].get<float>();
                    Config::colViewmodelChams.z = arr[2].get<float>();
                    Config::colViewmodelChams.w = arr[3].get<float>();
                }

                if (j.contains("colVisualChams") && j["colVisualChams"].is_array() && j["colVisualChams"].size() == 4)
                {
                    auto arr = j["colVisualChams"];
                    Config::colVisualChams.x = arr[0].get<float>();
                    Config::colVisualChams.y = arr[1].get<float>();
                    Config::colVisualChams.z = arr[2].get<float>();
                    Config::colVisualChams.w = arr[3].get<float>();
                }

                if (j.contains("colVisualChamsIgnoreZ") && j["colVisualChamsIgnoreZ"].is_array() && j["colVisualChamsIgnoreZ"].size() == 4)
                {
                    auto arr = j["colVisualChamsIgnoreZ"];
                    Config::colVisualChamsIgnoreZ.x = arr[0].get<float>();
                    Config::colVisualChamsIgnoreZ.y = arr[1].get<float>();
                    Config::colVisualChamsIgnoreZ.z = arr[2].get<float>();
                    Config::colVisualChamsIgnoreZ.w = arr[3].get<float>();
                }

                if (j.contains("teamcolVisualChamsIgnoreZ") && j["teamcolVisualChamsIgnoreZ"].is_array() && j["teamcolVisualChamsIgnoreZ"].size() == 4)
                {
                    auto arr = j["teamcolVisualChamsIgnoreZ"];
                    Config::teamcolVisualChamsIgnoreZ.x = arr[0].get<float>();
                    Config::teamcolVisualChamsIgnoreZ.y = arr[1].get<float>();
                    Config::teamcolVisualChamsIgnoreZ.z = arr[2].get<float>();
                    Config::teamcolVisualChamsIgnoreZ.w = arr[3].get<float>();
                }

                if (j.contains("teamcolVisualChams") && j["teamcolVisualChams"].is_array() && j["teamcolVisualChams"].size() == 4)
                {
                    auto arr = j["teamcolVisualChams"];
                    Config::teamcolVisualChams.x = arr[0].get<float>();
                    Config::teamcolVisualChams.y = arr[1].get<float>();
                    Config::teamcolVisualChams.z = arr[2].get<float>();
                    Config::teamcolVisualChams.w = arr[3].get<float>();
                }

                if (j.contains("fovCircleColor") && j["fovCircleColor"].is_array() && j["fovCircleColor"].size() == 4) {
                    auto arr = j["fovCircleColor"];
                    Config::fovCircleColor.x = arr[0].get<float>();
                    Config::fovCircleColor.y = arr[1].get<float>();
                    Config::fovCircleColor.z = arr[2].get<float>();
                    Config::fovCircleColor.w = arr[3].get<float>();
                }

				Config::aimbot = j.value("aimbot", false);
				Config::aimbot_fov = j.value("aimbot_fov", 90.0f);
				Config::aimbot_teamcheck = j.value("aimbot_teamcheck", false);
				Config::aimbot_wallcheck = j.value("aimbot_wallcheck", false);
				Config::aimbot_silent = j.value("aimbot_silent", false);
				Config::aimbot_smooth = j.value("aimbot_smooth", 1.0f);
				Config::aimbot_autoshoot = j.value("aimbot_autoshoot", false);
				Config::aimbot_hitbox = j.value("aimbot_hitbox", 0);
				Config::rcs = j.value("rcs", false);
				Config::rcs_strength = j.value("rcs_strength", 1.0f);
				Config::fov_circle = j.value("fov_circle", false);

                Config::enemyChamsInvisible = j.value("enemyChamsInvisible", false);
                Config::enemyChams = j.value("enemyChams", false);
                Config::teamChams = j.value("teamChams", false);
                Config::teamChamsInvisible = j.value("teamChamsInvisible", false);
                Config::chamsMaterial = j.value("chamsMaterial", 0);
                Config::antiflash = j.value("antiflash", false);
                Config::armChams = j.value("armChams", false);
                Config::viewmodelChams = j.value("viewmodelChams", false);
                Config::chatspam = j.value("chatspam", false);
                Config::bunnyhop = j.value("bunnyhop", false);
                Config::airstrafe = j.value("airstrafe", false);
                Config::nosmoke = j.value("nosmoke", false);
                Config::watermark = j.value("watermark", true);
                Config::autoaccept = j.value("autoaccept", false);
                Config::enableaspectratio = j.value("enableaspectratio", false);
                Config::aspectratio = j.value("aspectratio", 1.0f);

                ifs.close();
            }
            catch (const std::exception& e)
            {
                std::cerr << "Error loading config: " << e.what() << std::endl;
            }
        }

        static void Remove(const std::string& configName)
        {
            auto filePath = GetConfigPath(configName);
            std::error_code ec;
            if (!std::filesystem::remove(filePath, ec) && ec)
            {
                std::cerr << "Failed to remove config file: " << ec.message() << std::endl;
            }
        }
    };
}
