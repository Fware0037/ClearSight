﻿#include "../../../cs2/entity/C_CSPlayerPawn/C_CSPlayerPawn.h"
#include "../../../templeware/interfaces/CGameEntitySystem/CGameEntitySystem.h"
#include "../../../templeware/interfaces/interfaces.h"
#include "../../../templeware/hooks/hooks.h"
#include "../../../templeware/config/config.h"
#include <algorithm>
#include "aim.h"
#include <thread> 

int m_entitySpottedState = 0x23D0; // EntitySpottedState_t
int m_bSpotted = 0x8; // bool
int m_bSpottedByMask = 0xC;

Vector_t GetEntityEyePos(const C_CSPlayerPawn* Entity) {
    if (!Entity)
        return {};

    uintptr_t game_scene_node = *reinterpret_cast<uintptr_t*>((uintptr_t)Entity + SchemaFinder::Get(hash_32_fnv1a_const("C_BaseEntity->m_pGameSceneNode")));

    auto Origin = *reinterpret_cast<Vector_t*>(game_scene_node + SchemaFinder::Get(hash_32_fnv1a_const("CGameSceneNode->m_vecAbsOrigin")));
    auto ViewOffset = *reinterpret_cast<Vector_t*>((uintptr_t)Entity + SchemaFinder::Get(hash_32_fnv1a_const("C_BaseModelEntity->m_vecViewOffset")));

    Vector_t Result = Origin + ViewOffset;
    if (!std::isfinite(Result.x) || !std::isfinite(Result.y) || !std::isfinite(Result.z))
        return {};

    return Result;
}

inline QAngle_t CalcAngles(Vector_t viewPos, Vector_t aimPos)
{
    QAngle_t angle = { 0, 0, 0 };

    Vector_t delta = aimPos - viewPos;

    angle.x = -asin(delta.z / delta.Length()) * (180.0f / 3.141592654f);
    angle.y = atan2(delta.y, delta.x) * (180.0f / 3.141592654f);

    return angle;
}

inline float GetFov(const QAngle_t& viewAngle, const QAngle_t& aimAngle)
{
    QAngle_t delta = (aimAngle - viewAngle).Normalize();

    return sqrtf(powf(delta.x, 2.0f) + powf(delta.y, 2.0f));
}

QAngle_t Smooth(const QAngle_t& current, const QAngle_t& target, float smoothFactor) {
    QAngle_t delta = target - current;
    delta = delta.Normalize();
    return current + (delta / smoothFactor);
}

bool IsTargetVisible(C_CSPlayerPawn* pawn)
{
    if (!pawn)
        return false;

    uintptr_t spottedAddress = reinterpret_cast<uintptr_t>(pawn) + m_entitySpottedState + m_bSpotted;
    bool spotted = *reinterpret_cast<bool*>(spottedAddress);

    return spotted;
}

void Aimbot() {
    if (!Config::aimbot)
        return;

    C_CSPlayerPawn* lp = H::oGetLocalPlayer(0);
    if (!lp || !lp->m_IsAlive())
        return;

    uintptr_t clientModule = modules.getModule("client");
    if (!clientModule) {
        return; 
    }

    Vector_t lep = GetEntityEyePos(lp);
    QAngle_t* viewangles = (QAngle_t*)(clientModule + 0x1A93300);

    int nMaxHighestEntity = I::GameEntity->Instance->GetHighestEntityIndex();

    C_CSPlayerPawn* bestTarget = nullptr;
    float bestFov = Config::aimbot_fov;

    for (int i = 1; i <= nMaxHighestEntity; i++) {
        auto Entity = I::GameEntity->Instance->Get(i);
        if (!Entity || !Entity->handle().valid())
            continue;

        SchemaClassInfoData_t* _class = nullptr;
        Entity->dump_class_info(&_class);
        if (!_class)
            continue;

        if (HASH(_class->szName) != HASH("C_CSPlayerPawn"))
            continue;

        C_CSPlayerPawn* pawn = (C_CSPlayerPawn*)Entity;

        if (pawn == lp || pawn->getHealth() <= 0)
            continue;

        if (Config::aimbot_teamcheck && pawn->getTeam() == lp->getTeam())
            continue;

        if (Config::aimbot_wallcheck && !IsTargetVisible(pawn))
            continue;

        Vector_t enemyEyePos = GetEntityEyePos(pawn);
        QAngle_t angleToEnemy = CalcAngles(enemyEyePos, lep);

        angleToEnemy.x *= -1.f;
        angleToEnemy.y += 180.f;

        float currentFov = GetFov(*viewangles, angleToEnemy);

        if (!std::isfinite(currentFov) || currentFov > bestFov)
            continue;

        bestFov = currentFov;
        bestTarget = pawn;
    }

    if (bestTarget) {
        Vector_t targetEyePos = GetEntityEyePos(bestTarget);
        QAngle_t angle = CalcAngles(targetEyePos, lep);

        angle.x *= -1.f;
        angle.y += 180.f;
        angle.z = 0.f;
        angle = angle.Normalize();

        QAngle_t punch = *(QAngle_t*)((uintptr_t)lp + SchemaFinder::Get(hash_32_fnv1a_const("C_CSPlayerPawn->m_aimPunchAngle")));

        float smoothness = std::clamp(Config::aimbot_smooth, 1.0f, 30.0f);
        QAngle_t finalAngle = Smooth(*viewangles, angle, smoothness);

        *viewangles = finalAngle;
    }
}

void NewRCS() {
    if (!Config::rcs)
        return;

    C_CSPlayerPawn* lp = H::oGetLocalPlayer(0);

    if (!lp || !lp->m_IsAlive())
        return;

    static QAngle_t oldPunch = { 0.f, 0.f, 0.f };

    QAngle_t* viewangles = (QAngle_t*)(modules.getModule("client") + 0x1A93300);
    QAngle_t currentPunch = *(QAngle_t*)((uintptr_t)lp + SchemaFinder::Get(hash_32_fnv1a_const("C_CSPlayerPawn->m_aimPunchAngle")));

    if (lp->getShotsFired() > 1) {
        QAngle_t rcsCompensation = (currentPunch - oldPunch) * Config::rcs_strength;
        viewangles->x -= rcsCompensation.x; 
        viewangles->y -= rcsCompensation.y; // kinda shity
    }

    oldPunch = currentPunch;
}
