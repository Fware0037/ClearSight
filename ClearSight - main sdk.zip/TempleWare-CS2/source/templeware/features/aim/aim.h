#pragma once
#include <cstdint>
#include <string>
#include "../TempleWare-CS2/source/templeware/utils/math/vector/vector.h"
#include "../../../templeware/utils/cmds/UserCmds.h"

//Vector_t GetEntityEyePos(C_CSPlayerPawn* entity);
void CalcAngles(const Vector_t& src, const Vector_t& dst, Vector_t& angles);
float GetFov(const Vector_t& viewAngles, const Vector_t& aimAngles);

void Aimbot();
void NewRCS();
bool IsTargetVisible(C_CSPlayerPawn* pawn);
void AutoFire(C_CSPlayerPawn* lp, C_CSPlayerPawn* target);