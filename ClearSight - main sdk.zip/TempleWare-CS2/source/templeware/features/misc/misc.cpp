﻿#include <algorithm>
#include <iostream>
#include "../../hooks/hooks.h"
#include "../../players/players.h"
#include "../../config/config.h"
#include "../../../../external/imgui/imgui.h"
#include "misc.h"
#include "../../utils/cmds/UserCmds.h"
#include "../../utils/memory/Interface/Interface.h"
#include "../../utils/memory/patternscan/patternscan.h"
#include "../TempleWare-CS2/source/templeware/interfaces/interfaces.h"

/*



						* PLEASE RECODE THE TAB  *
						*/