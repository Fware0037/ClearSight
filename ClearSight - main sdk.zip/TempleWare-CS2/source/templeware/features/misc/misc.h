#pragma once
#include <cstdint>
#include "../../../cs2/entity/C_BaseEntity/C_BaseEntity.h"
#include "../../../cs2/entity/C_Material/C_Material.h"
#include "../../utils/math/utlstronghandle/utlstronghandle.h"

struct UserCmd;

namespace misc
{
	void chatspam();
	void bunnyhop();
	void airstrafe();
	void viewmodelpidar();
	void autoaccept();
	void aspectratio();
	
}

enum MoveType : std::uint8_t {
	MOVETYPE_NONE = 0,
	MOVETYPE_OBSOLETE = 1,
	MOVETYPE_WALK = 2,
	MOVETYPE_STEP = 3,
	MOVETYPE_FLY = 4,
	MOVETYPE_FLYGRAVITY = 5,
	MOVETYPE_VPHYSICS = 6,
	MOVETYPE_PUSH = 7,
	MOVETYPE_NOCLIP = 8,
	MOVETYPE_OBSERVER = 9,
	MOVETYPE_LADDER = 10,
	MOVETYPE_CUSTOM = 11,
	MOVETYPE_LAST = 12,
	MOVETYPE_MAX_BITS = 5,
};