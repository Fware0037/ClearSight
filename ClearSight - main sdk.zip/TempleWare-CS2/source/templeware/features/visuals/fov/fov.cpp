#include "../../../hooks/hooks.h"
#include "../../../config/config.h"
#include "../../../interfaces/interfaces.h"
#include "../../../interfaces/IEngineClient/IEngineClient.h"
#include "../../ClearSight - main sdk/TempleWare-CS2/source/cs2/entity/C_CSPlayerPawn/C_CSPlayerPawn.h"

float H::hkGetRenderFov(void* rcx) { // fixed zoom when player is scoped
    auto engine = I::EngineClient;
    auto lp = H::oGetLocalPlayer(0);

    if (!lp || !engine || !engine->in_game()) {
        return H::GetRenderFov.GetOriginal()(rcx);
    }

    if (lp->IsScoped()) {
        g_flActiveFov = H::GetRenderFov.GetOriginal()(rcx);
    }
    else {
        if (Config::fovEnabled) {
            g_flActiveFov = Config::fov; 
        }
        else {
            g_flActiveFov = H::GetRenderFov.GetOriginal()(rcx); 
        }
    }
    return g_flActiveFov;
}