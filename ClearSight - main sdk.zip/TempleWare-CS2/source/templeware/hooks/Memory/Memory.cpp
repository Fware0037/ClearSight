#include "Memory.h"

#include "../../interfaces/interfaces.h"
//#include "Utils.h"

Memory::Memory() noexcept
{
    //createMove = clientModule.FindPattern(SIGNATURE("48 8B C4 48 89 58 10 48 89 48 08 55 56 57 41 54 41 55")).get<std::uintptr_t>();
}
