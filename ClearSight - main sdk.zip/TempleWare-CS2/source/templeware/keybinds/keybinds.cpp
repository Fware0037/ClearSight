﻿#include "keybinds.h"
#include <Windows.h>
#include <unordered_map>
#include "../../../external/imgui/imgui.h"
#include "../config/config.h"
#include <string>

constexpr DWORD DELAY_MS = 200; // Deay in milliseconds

Keybind::Keybind(bool& v, int k)
    : var(v), key(k), isListening(false), skipFrame(false) {
}

Keybinds::Keybinds() {
    keybinds.emplace_back(Keybind(Config::aimbot, VK_MBUTTON)); // AIM
}

std::unordered_map<int, DWORD> lastPressTime;

void Keybinds::pollInputs() {
    DWORD currentTime = GetTickCount();

    for (Keybind& k : keybinds) {
        if ((GetAsyncKeyState(k.key) & 0x8001) != 0) {
            if (currentTime - lastPressTime[k.key] >= DELAY_MS) {
                k.var = !k.var;
                lastPressTime[k.key] = currentTime;
            }
        }
    }
}

std::string keyToString(int key) {
    if (key >= 'A' && key <= 'Z')
        return std::string(1, static_cast<char>(key));
    if (key >= VK_F1 && key <= VK_F24)
        return "F" + std::to_string(key - VK_F1 + 1);
    switch (key) {
    case VK_INSERT: return "INSERT";
    case VK_DELETE: return "DELETE";
    case VK_HOME: return "HOME";
    case VK_END: return "END";
    case VK_PRIOR: return "PAGE UP";
    case VK_NEXT: return "PAGE DOWN";
    case VK_SPACE: return "SPACE";
    case VK_TAB: return "TAB";
    case VK_SHIFT: return "SHIFT";
    case VK_CONTROL: return "CTRL";
    case VK_MENU: return "ALT";
    case VK_LBUTTON: return "MOUSE1";
    case VK_RBUTTON: return "MOUSE2";
    case VK_MBUTTON: return "MOUSE3";
    case VK_XBUTTON1: return "MOUSE4";
    case VK_XBUTTON2: return "MOUSE5";
    default: return "KEY " + std::to_string(key);
    }
}

void Keybinds::menuButton(bool& var) {
    for (auto& kb : keybinds) {
        if (&kb.var != &var) continue;

        if (!kb.isListening) {
            std::string buttonLabel = keyToString(kb.key);
            if (ImGui::Button(buttonLabel.c_str())) {
                kb.isListening = true;
                kb.skipFrame = true;
            }
        }
        else {
            ImGui::Text("Press any key (ESC to cancel)...");
            ImGui::SameLine();
            if (ImGui::Button("Cancel") || (GetAsyncKeyState(VK_ESCAPE) & 1)) {
                kb.isListening = false;
                return;
            }

            if (!kb.skipFrame) {
                for (int keyCode = 7; keyCode < 256; ++keyCode) {
                    if (GetAsyncKeyState(keyCode) & 0x8000) {
                        while (GetAsyncKeyState(keyCode) & 0x8000);
                        kb.key = keyCode;
                        kb.isListening = false;
                        return;
                    }
                }
            }
            else {
                kb.skipFrame = false;
            }
        }
    }
}

Keybinds keybind;
