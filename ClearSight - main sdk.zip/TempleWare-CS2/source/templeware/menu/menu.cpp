﻿#include "menu.h"
#include "../config/config.h"
#include <d3d11.h>
#include "stb_image.h" // Если используешь stb_image для загрузки текстур
#include <iostream>
#include <vector>
#include "../config/configmanager.h"
#include <Windows.h>
#include "../keybinds/keybinds.h"
#include "../ClearSight - main sdk/TempleWare-CS2/source/templeware/interfaces/interfaces.h"
#include "../utils/logging/log.h"
#include <source\templeware\hooks\hooks.h>

bool menu_open = false; 

void ApplyImGuiTheme() {
    ImGui::StyleColorsDark();

    ImGuiStyle& style = ImGui::GetStyle();
    ImVec4* colors = style.Colors;

    colors[ImGuiCol_WindowBg] = ImVec4(0.09f, 0.09f, 0.09f, 1.0f);
    colors[ImGuiCol_Border] = ImVec4(0.30f, 0.30f, 0.30f, 1.0f);
    colors[ImGuiCol_FrameBg] = ImVec4(0.16f, 0.16f, 0.16f, 1.0f);
    colors[ImGuiCol_FrameBgHovered] = ImVec4(0.24f, 0.24f, 0.24f, 1.0f);
    colors[ImGuiCol_FrameBgActive] = ImVec4(0.24f, 0.24f, 0.24f, 1.0f);
    colors[ImGuiCol_TitleBg] = ImVec4(0.09f, 0.09f, 0.09f, 1.0f);
    colors[ImGuiCol_TitleBgActive] = ImVec4(0.09f, 0.09f, 0.09f, 1.0f);

    colors[ImGuiCol_Button] = ImVec4(0.60f, 0.30f, 0.80f, 1.0f);
    colors[ImGuiCol_ButtonHovered] = ImVec4(0.70f, 0.40f, 0.90f, 1.0f);
    colors[ImGuiCol_ButtonActive] = ImVec4(0.50f, 0.20f, 0.70f, 1.0f);

    colors[ImGuiCol_CheckMark] = ImVec4(0.80f, 0.50f, 1.00f, 1.0f);
    colors[ImGuiCol_SliderGrab] = ImVec4(0.60f, 0.30f, 0.80f, 1.0f);
    colors[ImGuiCol_SliderGrabActive] = ImVec4(0.70f, 0.40f, 0.90f, 1.0f);

    colors[ImGuiCol_Header] = ImVec4(0.60f, 0.30f, 0.80f, 1.0f);
    colors[ImGuiCol_HeaderHovered] = ImVec4(0.70f, 0.40f, 0.90f, 1.0f);
    colors[ImGuiCol_HeaderActive] = ImVec4(0.50f, 0.20f, 0.70f, 1.0f);

    colors[ImGuiCol_Separator] = ImVec4(0.50f, 0.20f, 0.70f, 1.0f);
    colors[ImGuiCol_SeparatorHovered] = ImVec4(0.60f, 0.30f, 0.80f, 1.0f);
    colors[ImGuiCol_SeparatorActive] = ImVec4(0.70f, 0.40f, 0.90f, 1.0f);

    colors[ImGuiCol_Text] = ImVec4(1.00f, 1.00f, 1.00f, 1.00f);

    style.WindowRounding = 0.0f;
    style.FrameRounding = 0.0f;
    style.ScrollbarRounding = 0.0f;
    style.GrabRounding = 0.0f;

    style.ItemSpacing = ImVec2(10, 5);
    style.FramePadding = ImVec2(5, 5);
}

Menu::Menu() {
    activeTab = 0;
    showPiska = true;
	//ImGui::GetIO().MouseDrawCursor = true;
}

void Menu::init(HWND& window, ID3D11Device* pDevice, ID3D11DeviceContext* pContext, ID3D11RenderTargetView* mainRenderTargetView) {
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.ConfigFlags = ImGuiConfigFlags_NoMouseCursorChange;
    ImGui_ImplWin32_Init(window);
    ImGui_ImplDX11_Init(pDevice, pContext);

    ApplyImGuiTheme();

    io.Fonts->AddFontFromFileTTF("C:\\Windows\\Fonts\\arial.ttf", 16.0f);
    std::cout << "initialized menu\n";
}

std::string GetUserNameStr() {
    char username[256];
    DWORD size = sizeof(username);
    if (GetUserNameA(username, &size)) {
        return std::string(username);
    }
    return "t.me/priora_crack";
}

void SetCursorAlwaysVisible(bool visible)
{
    CURSORINFO cursorInfo;
    cursorInfo.cbSize = sizeof(CURSORINFO);

    if (GetCursorInfo(&cursorInfo))
    {
        if (visible)
        {
            if (cursorInfo.flags == CURSOR_SUPPRESSED)
            {
                ShowCursor(TRUE);
            }
        }
        else
        {
            if (cursorInfo.flags == CURSOR_SHOWING)
            {
                ShowCursor(FALSE);
            }
        }
    }
}

void Menu::render() {
    keybind.pollInputs();
    ImGuiIO& io = ImGui::GetIO();

    if (showPiska) {
        ImGuiWindowFlags window_flags = ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoCollapse |
            ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoTitleBar;

        ImGui::SetNextWindowSize({ 734.f,477.f });
        ImGui::Begin("ClearSight", nullptr, window_flags);

        
        ImGui::SetCursorPos({ 12.f,14.f });
        ImGui::TextColored(ImVec4(0.7f, 0.2f, 1.0f, 1.0f), "ClearSight");

        const char* tabs[] = { "aimbot", "esp", "world", "misc" };
        for (int i = 0; i < 4; i++) {
            ImGui::SetCursorPos({ 12.f, 38.f + i * 31.f });
            if (ImGui::Button(tabs[i], { 57.f, 23.f })) {
                activeTab = i;
            }
        }

        ImVec4 purpleColor = ImVec4(0.5f, 0.0f, 1.0f, 1.0f);
        std::string welcomeText = "Welcome back, " + GetUserNameStr() + "!";
        ImGui::SetCursorPos({ 15.f,454.f });
        ImGui::Text("offical release - 1.0.h3");
        ImGui::SetCursorPos({ 550.f,454.f });
        ImGui::TextColored(purpleColor, welcomeText.c_str());

        ImGui::SetCursorPos({ 87.f,37.f });
        ImGui::BeginChild("Main Content", ImVec2(340, 410), true);

        if (activeTab == 0) {
            ImGui::Text("Aim");
            ImGui::Separator();
            ImGui::Checkbox("Aimbot [R.I.S.K]", &Config::aimbot); ImGui::SameLine();
            keybind.menuButton(Config::aimbot);
            if (Config::aimbot)
            {
               // ImGui::Checkbox("Silent Aim", &Config::aimbot_silent);
				ImGui::Checkbox("IsSpotted", &Config::aimbot_wallcheck);
                ImGui::Checkbox("TeamCheck", &Config::aimbot_teamcheck);
                ImGui::Checkbox("DrawFOV", &Config::fov_circle);
				//ImGui::Checkbox("AutoShoot", &Config::aimbot_autoshoot);
            }
        }
        else if (activeTab == 1) {
            ImGui::Text("Visuals");
            ImGui::Separator();
            ImGui::Checkbox("TeamCheck", &Config::teamCheck);
			ImGui::Checkbox("NameTags", &Config::showNameTags);
			ImGui::Checkbox("Health", &Config::showHealth);
            ImGui::Checkbox("Box", &Config::esp);
			ImGui::Checkbox("BoxFill", &Config::espFill);
            ImGui::ColorEdit4("Box Color", (float*)&Config::espColor);
        }
        else if (activeTab == 2) {
            ImGui::Text("World");
            ImGui::Separator();
            ImGui::Checkbox("NightMode [Experimental]", &Config::Night);
            ImGui::ColorEdit4("Night Color", (float*)&Config::NightColor);
        }
        else if (activeTab == 3) {
            ImGui::Text("Misc");
            ImGui::Separator();
            ImGui::Checkbox("Watermark", &Config::watermark);
			//ImGui::Checkbox("Bunnyhop", &Config::bunnyhop);
            if (ImGui::Button("Open Offical Telegram"))
            {
                ShellExecute(0, "open", "https://t.me/priora_crack", 0, 0, SW_SHOW);
            }
        }

        ImGui::EndChild();

    
        ImGui::SetCursorPos({ 440.f,37.f });
        ImGui::BeginChild("Secondary Content", ImVec2(260, 410), true);

        if (activeTab == 0) {
            const char* hitboxOptions[] = { "Head", "Neck", "Chest", "Stomach", "Pelvis" };
            ImGui::Text("Aim Settings");
            ImGui::Separator();
            ImGui::Checkbox("RCS", &Config::rcs);
            if (Config::rcs)
                ImGui::SliderFloat("RCS Str", &Config::rcs_strength, 0.f, 2.f);
            ImGui::Separator();
            if (Config::aimbot)
            {
                ImGui::SliderFloat("FOV", &Config::aimbot_fov, 0.f, 90.f);
                if (!Config::aimbot_silent)
                    ImGui::SliderFloat("Smooth", &Config::aimbot_smooth, 0.f, 30.f);
                if (Config::fov_circle) {
                    ImGui::ColorEdit4("Color##FovColor", (float*)&Config::fovCircleColor);
                }
               // ImGui::Separator();
               // ImGui::Combo("Hitbox", &Config::aimbot_hitbox, hitboxOptions, IM_ARRAYSIZE(hitboxOptions));

            }
        }
        else if (activeTab == 1) {
            ImGui::Text("Chams");
            ImGui::Separator();
            if (ImGui::CollapsingHeader("Chams")) {
                ImGui::Checkbox("Chams##ChamsCheckbox", &Config::enemyChams);
                const char* chamsMaterials[] = { "Flat", "Illuminate", "Glow" };
                ImGui::Combo("Material", &Config::chamsMaterial, chamsMaterials, IM_ARRAYSIZE(chamsMaterials));
                if (Config::enemyChams) {
                    ImGui::ColorEdit4("Color##ChamsColor", (float*)&Config::colVisualChams);
                }
                ImGui::Checkbox("Chams-XQZ", &Config::enemyChamsInvisible);
                if (Config::enemyChamsInvisible) {
                    ImGui::ColorEdit4("Color-XQZ##ChamsXQZColor", (float*)&Config::colVisualChamsIgnoreZ);
                }
                ImGui::Checkbox("HandChams", &Config::armChams);
                if (Config::armChams) {
                    ImGui::ColorEdit4("Color##HandChamsColor", (float*)&Config::colArmChams);
                }
                ImGui::Checkbox("ViewmodelChams", &Config::viewmodelChams);
                if (Config::viewmodelChams) {
                    ImGui::ColorEdit4("Color##ViewModelChamsColor", (float*)&Config::colViewmodelChams);
                }
            }
        }
        else if (activeTab == 2) {
            ImGui::Text("LocalPlayer");
            ImGui::Separator();
            ImGui::Checkbox("Antiflash##antiflashcheckbox", &Config::antiflash);
            // ImGui::Checkbox("NoSmoke", &Config::nosmoke);

            ImGui::Checkbox("Fov", &Config::fovEnabled);
            if (Config::fovEnabled) {
                ImGui::SliderFloat("##FovSlider", &Config::fov, 20.0f, 160.0f, "%1.0f");
            }

           // ImGui::Checkbox("Night Mode", &Config::Night);
           // ImGui::ColorEdit4("Night Color", (float*)&Config::NightColor);
        }
        else if (activeTab == 3) {
            ImGui::Text("Config Manager");
            ImGui::Separator();
            static char configName[128] = "";
            static std::vector<std::string> configList = internal_config::ConfigManager::ListConfigs();
            static int selectedConfigIndex = -1;

            ImGui::InputText("Config Name", configName, IM_ARRAYSIZE(configName));
            if (ImGui::Button("Refresh")) {
                configList = internal_config::ConfigManager::ListConfigs();
            }
            ImGui::SameLine();
            if (ImGui::Button("Load")) {
                internal_config::ConfigManager::Load(configName);
            }
            ImGui::SameLine();
            if (ImGui::Button("Save")) {
                internal_config::ConfigManager::Save(configName);
                configList = internal_config::ConfigManager::ListConfigs();
            }
            ImGui::SameLine();
            if (ImGui::Button("Delete")) {
                internal_config::ConfigManager::Remove(configName);
                configList = internal_config::ConfigManager::ListConfigs();
            }

            if (ImGui::Button("Open Config Folder")) {
                auto configFolder = internal_config::ConfigManager::GetConfigFolder();
                ShellExecuteA(nullptr, "open", configFolder.string().c_str(), nullptr, nullptr, SW_SHOW);
            }

            ImGui::Separator();
            ImGui::Text("Saved Configs:");
            for (int i = 0; i < static_cast<int>(configList.size()); i++) {
                if (ImGui::Selectable(configList[i].c_str(), selectedConfigIndex == i)) {
                    selectedConfigIndex = i;
                    strncpy_s(configName, sizeof(configName), configList[i].c_str(), _TRUNCATE);
                }
            }
        }

        ImGui::EndChild();
        ImGui::End();
    }
}
void Menu::toggleMenu() {
    showPiska = !showPiska;

    ImGuiIO& io = ImGui::GetIO();

    if (showPiska) {
        io.MouseDrawCursor = true;
        SetCursorAlwaysVisible(true);
        io.ConfigFlags &= ~ImGuiConfigFlags_NoMouse;
        ClipCursor(nullptr);
    }
    else {
        io.MouseDrawCursor = false;
        SetCursorAlwaysVisible(false);
        io.ConfigFlags |= ImGuiConfigFlags_NoMouse;

        HWND foregroundWindow = GetForegroundWindow();
        if (foregroundWindow == GetConsoleWindow() || foregroundWindow == nullptr) {
            return; 
        }

        RECT windowRect;
        GetWindowRect(foregroundWindow, &windowRect);
        ClipCursor(&windowRect);
    }
}

