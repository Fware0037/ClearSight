#pragma once
#include <Windows.h>
#include <d3d11.h>
#include "../../../external/imgui/imgui.h"
#include "../../../external/imgui/imgui_impl_dx11.h"
#include "../../../external/imgui/imgui_impl_win32.h"

//void HandleCameraLock();
//bool showPiska;
class Menu {
public:
	//void HandleCameraLock();
	Menu();
	bool showPiska;
	void init(HWND& window, ID3D11Device* pDevice, ID3D11DeviceContext* pContext, ID3D11RenderTargetView* mainRenderTargetView);
	void render();

	void toggleMenu();
private:
	//bool showMenu;
	//bool showPiska;
	int activeTab;
};
