#pragma once
#include <cstddef>

namespace Offset {
	constexpr std::ptrdiff_t dwLocalPlayerPawn = 0x188BF30;

	namespace C_BasePlayerPawn {
		constexpr std::ptrdiff_t m_vOldOrigin = 0x1324;
		constexpr std::ptrdiff_t m_iHealth = 0x344;
		constexpr std::ptrdiff_t m_iTeamNum = 0x3E3;
		constexpr std::ptrdiff_t m_vecViewOffset = 0xCB0; // Vector
		constexpr std::ptrdiff_t m_vecVelocity = 0x1A0; // Vector
		constexpr std::ptrdiff_t m_vecBaseVelocity = 0x1AC; // Vector
		constexpr std::ptrdiff_t m_vecAbsOrigin = 0x1B0; // Vector
		constexpr std::ptrdiff_t m_vecAbsVelocity = 0x1C4; // Vector
		constexpr std::ptrdiff_t m_flMaxspeed = 0x1E0; // float
		constexpr std::ptrdiff_t m_flFallVelocity = 0x1E4; // float
		constexpr std::ptrdiff_t m_flDuckAmount = 0x1E8; // float
		constexpr std::ptrdiff_t m_flWaterJumpTime = 0x1EC; // float
		constexpr std::ptrdiff_t m_flStepSize = 0x1F0; // float
		constexpr std::ptrdiff_t m_flNextAttack = 0x1F4; // float
		constexpr std::ptrdiff_t m_flFOV = 0x1F8; // float
		constexpr std::ptrdiff_t m_flFOVRate = 0x1FC; // float
		constexpr std::ptrdiff_t m_flFOVTime = 0x200; // float
		constexpr std::ptrdiff_t m_flFOVTarget = 0x204; // float
		constexpr std::ptrdiff_t m_flFOVTimeTarget = 0x208; // float
		constexpr std::ptrdiff_t m_flFOVTimeStart = 0x20C; // float
		constexpr std::ptrdiff_t m_flFOVTimeEnd = 0x210; // float
		constexpr std::ptrdiff_t m_flFOVTimeDelta = 0x214; // float
		constexpr std::ptrdiff_t m_bIsScoped = 0x22A0; // bool

	}
}
