#include "players.h"
#include "../offsets/offsets.h"
// sosite
std::vector<CCSPlayerController> Players::controllers;
std::vector<C_CSPlayerPawn> Players::pawns;