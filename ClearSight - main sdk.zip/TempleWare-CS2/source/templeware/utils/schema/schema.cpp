#include "schema.h"
#include <vector>
#include <unordered_map>
#include <algorithm>
#include <Shlobj.h>
#include <shlobj_core.h>
#include "../fnv1a/fnv1a.h"
#include "../math/utlstring/utlstring.h"
#include "../memory/Interface/Interface.h"
#include <iostream>

static std::unordered_map<uint32_t, std::uint32_t> dumped_data;

bool Schema::init(const char* ModuleName, int module_type) {
    schema_system = I::Get<ISchemaSystem>("schemasystem.dll", "SchemaSystem_00");
    if (!schema_system) {
        std::cerr << "[Schema] Error: Failed to get ISchemaSystem interface!" << std::endl;
        return false;
    }

    CSchemaSystemTypeScope* pTypeScope = schema_system->FindTypeScopeForModule(ModuleName);
    if (!pTypeScope) {
        std::cerr << "[Schema] Error: Failed to find type scope for module: " << ModuleName << std::endl;
        return false;
    }

    const int nTableSize = pTypeScope->hashClasses.Count();
    std::vector<UtlTSHashHandle_t> pElements(nTableSize);

    const auto nElements = pTypeScope->hashClasses.GetElements(0, nTableSize, pElements.data());
    for (int i = 0; i < nElements; i++) {
        const UtlTSHashHandle_t hElement = pElements[i];
        if (hElement == 0)
            continue;

        CSchemaClassBinding* pClassBinding = pTypeScope->hashClasses[hElement];
        if (!pClassBinding)
            continue;

        SchemaClassInfoData_t* pDeclaredClassInfo;
        pTypeScope->FindDeclaredClass(&pDeclaredClassInfo, pClassBinding->szBinaryName);

        if (!pDeclaredClassInfo || pDeclaredClassInfo->nFieldSize == 0)
            continue;

        for (int j = 0; j < pDeclaredClassInfo->nFieldSize; j++) {
            SchemaClassFieldData_t* pFields = pDeclaredClassInfo->pFields;
            std::string szFieldClassBuffer = std::string(pDeclaredClassInfo->szName) + "->" + std::string(pFields[j].szName);
            dumped_data[hash_32_fnv1a_const(szFieldClassBuffer.c_str())] = pFields[j].nSingleInheritanceOffset;
        }

        HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
        SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_INTENSITY);
        printf("[Schema] ");
        SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
        printf("Dumped Class: %s fields: %i \n", pDeclaredClassInfo->szName, pDeclaredClassInfo->nFieldSize);
    }

    return true;
}

std::uint32_t SchemaFinder::Get(const uint32_t hashedName) {
    auto it = dumped_data.find(hashedName);
    if (it != dumped_data.end())
        return it->second;

    return 0U; 
}
